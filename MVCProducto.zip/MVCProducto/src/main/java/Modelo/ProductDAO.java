package Modelo;

public class ProductDAO {
}
