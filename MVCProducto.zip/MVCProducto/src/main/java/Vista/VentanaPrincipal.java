package Vista;

import javax.swing.*;
import Controlador.*;

public class VentanaPrincipal {

    private JPanel Panel;
    private Controlador controlador;

    public static void main(String[] args) {
        JFrame frame = new JFrame("VentanaPrincipal");
        frame.setContentPane(new VentanaPrincipal().Panel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    public void setControlador(Controlador controlador) {
        this.controlador = controlador;
    }
}
