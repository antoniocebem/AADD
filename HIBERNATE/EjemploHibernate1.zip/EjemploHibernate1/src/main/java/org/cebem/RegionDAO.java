package org.cebem;

public class RegionDAO {
}
