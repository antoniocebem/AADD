import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionListener;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JScrollPane;

public class BuscarModificarCoche extends JDialog {

	private static final long serialVersionUID = 1L;
	private final JPanel contentPanel = new JPanel();
	private JTextField textFieldBuscar;
	private JTable table;
	private JTextField textFieldMatricula;
	private JTextField textFieldMarca;
	private JTextField textFieldModelo;
	private JTextField textFieldDesposito;
	private JTextField textFieldPrecio;
	private ArrayList<Coche> cochesImportados;
	private DefaultTableModel model;


	public BuscarModificarCoche(FormularioCoche frame, File coches) {
		setBounds(100, 100, 564, 360);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JComboBox comboBox = new JComboBox();
		
		comboBox.setBounds(6, 6, 109, 27);
		contentPanel.add(comboBox);
		comboBox.addItem("Matricula");
		comboBox.addItem("Marca");
		comboBox.addItem("Modelo");

		
		textFieldBuscar = new JTextField();
		textFieldBuscar.setBounds(115, 5, 130, 26);
		contentPanel.add(textFieldBuscar);
		textFieldBuscar.setColumns(10);
		
		JButton btnNewButton = new JButton("Buscar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String campoAbucar=textFieldBuscar.getText();
				if(campoAbucar.equals("")) {
					JOptionPane.showMessageDialog(null, "Introduzca datos para buscar");
				}else
				{
					String campo=comboBox.getSelectedItem().toString();
					String valorFiltrado=textFieldBuscar.getText();
					ArrayList <Coche> cochesFiltrados=new ArrayList<Coche>();
					if (campo.equals("Matricula")) {
						for(Coche c:cochesImportados) {
							if(c.getMatricula().equalsIgnoreCase(valorFiltrado)) {
								cochesFiltrados.add(c);
							}
						}
					}
					if(campo.equals("Marca")) {
						for(Coche c:cochesImportados) {
							if(c.getMarca().equalsIgnoreCase(valorFiltrado)) {
								cochesFiltrados.add(c);
							}
						}
					}
					if (campo.equals("Modelo")) {
						for(Coche c:cochesImportados) {
							if(c.getModelo().equalsIgnoreCase(valorFiltrado)) {
								cochesFiltrados.add(c);
							}
						}
					}
					
					for(Coche c:cochesFiltrados) {
						System.out.println(c);
					}
					
					actualizarTabla(model,cochesFiltrados);
					//table.setModel(model);
					
					
				}
				
				
				
				
			}
		});
		btnNewButton.setBounds(247, 5, 117, 29);
		contentPanel.add(btnNewButton);
		
		
		
		String[] columnNames = {"Marca", "Modelo", "Matrícula", "Capacidad Depósito", "Precio"};
		model = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                // Todas las celdas no son editables
                return false;
            }
        };
		
		try {
			FileInputStream fis=new FileInputStream(coches);
			ObjectInputStream ois = new ObjectInputStream(fis);
			cochesImportados=new ArrayList<Coche>();
			try {
				while(true) {
					Coche c=(Coche) ois.readObject();
					cochesImportados.add(c);
					model.addRow(new Object[] {c.getMarca(), c.getModelo(), c.getMatricula(), c.getTamanhoDeposito(), c.getPrecio()});
				}
			}catch(EOFException e1) {
				
			}
			ois.close();
			fis.close();
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(16, 177, 517, 95);
		contentPanel.add(scrollPane);
		
				table = new JTable(model);
				table.setAutoCreateRowSorter(true);
				
				scrollPane.setViewportView(table);
				table.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						if (e.getClickCount() == 1) { // Doble clic
                    int row = table.getSelectedRow();
                    if (row != -1) {
                        // Obtener los datos de la fila seleccionada
                        String marca = table.getValueAt(row, 0).toString();
                        String modelo = table.getValueAt(row, 1).toString();
                        String matricula = table.getValueAt(row, 2).toString();
								String deposito = table.getValueAt(row, 3).toString();
								String precio = table.getValueAt(row, 4).toString();
								
								// Mostrar los datos de la fila seleccionada
								textFieldMatricula.setText(matricula);
								textFieldMarca.setText(marca);
								textFieldModelo.setText(modelo);
								textFieldDesposito.setText(deposito);
								textFieldPrecio.setText(precio);
								
								textFieldMarca.setEditable(true);
								textFieldModelo.setEditable(true);
								textFieldDesposito.setEditable(true);
								textFieldPrecio.setEditable(true);
                        
                       
                    }
						}
					}
				});
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, null, TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel.setBounds(16, 40, 450, 125);
		contentPanel.add(panel);
		panel.setLayout(null);
		
		textFieldMatricula = new JTextField();
		textFieldMatricula.setEditable(false);
		textFieldMatricula.setBounds(79, 18, 130, 26);
		panel.add(textFieldMatricula);
		textFieldMatricula.setColumns(10);
		
		textFieldMarca = new JTextField();
		textFieldMarca.setEditable(false);
		textFieldMarca.setBounds(79, 56, 130, 26);
		panel.add(textFieldMarca);
		textFieldMarca.setColumns(10);
		
		textFieldModelo = new JTextField();
		textFieldModelo.setEditable(false);
		textFieldModelo.setBounds(79, 94, 130, 26);
		panel.add(textFieldModelo);
		textFieldModelo.setColumns(10);
		
		textFieldDesposito = new JTextField();
		textFieldDesposito.setEditable(false);
		textFieldDesposito.setBounds(314, 18, 130, 26);
		panel.add(textFieldDesposito);
		textFieldDesposito.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Matrícula");
		lblNewLabel.setBounds(8, 23, 61, 16);
		panel.add(lblNewLabel);
		
		JLabel lblMarca = new JLabel("Marca");
		lblMarca.setBounds(6, 61, 61, 16);
		panel.add(lblMarca);
		
		JLabel lblModelo = new JLabel("Modelo");
		lblModelo.setBounds(6, 99, 61, 16);
		panel.add(lblModelo);
		
		JLabel lblDepsito = new JLabel("Depósito");
		lblDepsito.setBounds(241, 24, 61, 16);
		panel.add(lblDepsito);
		
		JLabel lblNewLabel_3_1 = new JLabel("Precio");
		lblNewLabel_3_1.setBounds(241, 61, 61, 16);
		panel.add(lblNewLabel_3_1);
		
		textFieldPrecio = new JTextField();
		textFieldPrecio.setEditable(false);
		textFieldPrecio.setBounds(314, 56, 130, 26);
		panel.add(textFieldPrecio);
		textFieldPrecio.setColumns(10);
		
		JButton btnNewButton_1=new JButton("Modificar");
		btnNewButton_1.setBounds(16, 289, 117, 29);
		btnNewButton_1.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        // Modificar los datos del coche en el ArrayList
		        for (Coche c : cochesImportados) {
		            if (c.getMatricula().equals(textFieldMatricula.getText())) {
		                c.setMarca(textFieldMarca.getText());
		                c.setModelo(textFieldModelo.getText());
		                c.setTamanhoDeposito(Integer.parseInt(textFieldDesposito.getText()));
		                c.setPrecio(Double.parseDouble(textFieldPrecio.getText()));
		            }
		        }

		        // Guardar los cambios en el archivo
		        try (FileOutputStream fos = new FileOutputStream(coches);
		             ObjectOutputStream oos = new ObjectOutputStream(fos)) {
		            for (Coche coche : cochesImportados) {
		                oos.writeObject(coche);
		            }
		            JOptionPane.showMessageDialog(null, "Coches guardados correctamente", "Coches guardados", JOptionPane.INFORMATION_MESSAGE);
		        } catch (IOException e1) {
		            e1.printStackTrace();
		        }

		        // Actualizar la tabla con los datos modificados
				/*
				 * DefaultTableModel model = (DefaultTableModel) table.getModel();
				 * model.setRowCount(0); // Limpiar la tabla for (Coche c : cochesImportados) {
				 * model.addRow(new Object[]{c.getMarca(), c.getModelo(), c.getMatricula(),
				 * c.getTamanhoDeposito(), c.getPrecio()}); }
				 */
		        
		        model = (DefaultTableModel) table.getModel();
		        actualizarTabla(model, cochesImportados);
		    }
		});
		btnNewButton_1.setBounds(312, 94, 117, 29);
		panel.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Quitar filtros");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					FileInputStream fis=new FileInputStream(coches);
					ObjectInputStream ois = new ObjectInputStream(fis);
					cochesImportados=new ArrayList<Coche>();
					try {
						while(true) {
							Coche c=(Coche) ois.readObject();
							cochesImportados.add(c);
							model.addRow(new Object[] {c.getMarca(), c.getModelo(), c.getMatricula(), c.getTamanhoDeposito(), c.getPrecio()});

						}
					}catch(EOFException e1) {
						
					}
					ois.close();
					fis.close();
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}finally {
					actualizarTabla(model, cochesImportados);
					textFieldBuscar.setText("");

				}
			}
		});
		btnNewButton_2.setBounds(361, 5, 117, 29);
		contentPanel.add(btnNewButton_2);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						frame.refrescarTabla();
						dispose();
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						dispose();
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}
	
	public void actualizarTabla(DefaultTableModel model, ArrayList<Coche> coches) {
		model.setRowCount(0); // Limpiar la tabla
        for (Coche c : coches) {
            model.addRow(new Object[]{c.getMarca(), c.getModelo(), c.getMatricula(), c.getTamanhoDeposito(), c.getPrecio()});
        }
        //return model;
	}
}
