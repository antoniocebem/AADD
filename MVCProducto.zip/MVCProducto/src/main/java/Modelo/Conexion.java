package Modelo;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.*;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;

public class Conexion {

    private static final String RUTA_ARCHIVO = "DatosConexion.json";

    Connection conn = null;

    /** Constructor de DbConnection */
    public Conexion() {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();

        try (FileReader reader = new FileReader(RUTA_ARCHIVO)) {
            DatosConexionBD datos = gson.fromJson(reader, DatosConexionBD.class);
            String url = "jdbc:mysql://" + datos.getDirServer() + ":" + datos.getPuerto() + "/" + datos.getBaseDatos();
            System.out.println(url);
            conn = DriverManager.getConnection(url, datos.getUsuario(), datos.getClave());
            System.out.println("Conexión exitosa a la base de datos");
            reader.close();


            // Cerrar la conexión
            conn.close();
        } catch (IOException | SQLException e) {
            e.printStackTrace();
        }
    }
    public Connection getConnection(){
        return conn;
    }

    public void desconectar(){
        conn = null;
    }


}
