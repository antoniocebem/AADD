package Vista;

import javax.swing.*;
import Controlador.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VentanaPrincipal extends javax.swing.JFrame {

    private JPanel Panel;
    private JButton listarProductosButton;
    private JTextField editarProductoTextField;
    private Controlador controlador;
    private JFrame frame;

    public VentanaPrincipal()
    {
        super("Ventana principal");
        setContentPane(Panel);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        //setVisible(true);

        listarProductosButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               controlador.mostrarVentanaListado();
            }
        });
    }

    public void setControlador(Controlador controlador) {
        this.controlador = controlador;
    }


}
