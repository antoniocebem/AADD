package Controlador;

import Modelo.Conexion;
import Modelo.Logica;
import Vista.ListadoProductos;
import Vista.VentanaPrincipal;

public class Principal {

        Logica miLogica;
        Controlador miControlador;
        VentanaPrincipal miVentanaPrincipal;
        ListadoProductos miListadoProductos;
        //Ventanas

    public static void main(String[] args) {
        Principal principal = new Principal();
        principal.iniciar();
    }

    public void iniciar(){
        Controlador miControlador = new Controlador();
        miLogica = new Logica();
        miVentanaPrincipal = new VentanaPrincipal();
        miListadoProductos=new ListadoProductos();

        miLogica.setCoordinador(miControlador);
        miListadoProductos.setControlador(miControlador);
        miVentanaPrincipal.setControlador(miControlador);

        miControlador.setMiLogica(miLogica);
        miControlador.setVentanaPrincipal(miVentanaPrincipal);
        miControlador.setListadoProductos(miListadoProductos);

        miVentanaPrincipal.setVisible(true);

    }
}
