package Modelo;

import javax.swing.JOptionPane;
import Modelo.ProductDAO;
import Modelo.ProductVO;
import Controlador.Controlador;

public class Logica {

    private Controlador miCoordinador;
    public static boolean consultaProducto = false;
    public static boolean modificaProducto = false;

    public void setCoordinador(Controlador miCoordinador) {
        this.miCoordinador = miCoordinador;
    }

    public void validarRegistro(ProductVO miProducto) {
        ProductDAO miProductoDao;
        if (miProducto.getProductName() != null && miProducto.getProductName().length() > 3) {
            miProductoDao = new ProductDAO();
            miProductoDao.registrarProducto(miProducto);
        } else {
            JOptionPane.showMessageDialog(null, "El nombre del producto debe tener más de 3 caracteres", "Advertencia", JOptionPane.WARNING_MESSAGE);
        }
    }

    public ProductVO validarConsulta(String codigoProducto) {
        ProductDAO miProductoDao;

        try {
            int codigo = Integer.parseInt(codigoProducto);
            if (codigo > 0) {
                miProductoDao = new ProductDAO();
                consultaProducto = true;
                return miProductoDao.buscarProducto(codigo);
            } else {
                JOptionPane.showMessageDialog(null, "El código del producto debe ser mayor a 0", "Advertencia", JOptionPane.WARNING_MESSAGE);
                consultaProducto = false;
            }

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Debe ingresar un dato numérico", "Error", JOptionPane.ERROR_MESSAGE);
            consultaProducto = false;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Se ha presentado un Error", "Error", JOptionPane.ERROR_MESSAGE);
            consultaProducto = false;
        }

        return null;
    }

    public void validarModificacion(ProductVO miProducto) {
        ProductDAO miProductoDao;
        if (miProducto.getProductName() != null && miProducto.getProductName().length() > 3) {
            miProductoDao = new ProductDAO();
            miProductoDao.actualizarProducto(miProducto);
            modificaProducto = true;
        } else {
            JOptionPane.showMessageDialog(null, "El nombre del producto debe tener más de 3 caracteres", "Advertencia", JOptionPane.WARNING_MESSAGE);
            modificaProducto = false;
        }
    }

    public void validarEliminacion(String codigoProducto) {
        ProductDAO miProductoDao = new ProductDAO();
        try {
            int codigo = Integer.parseInt(codigoProducto);
            if (codigo > 0) {
                miProductoDao.borrarProducto(Integer.parseInt(codigoProducto));
            } else {
                JOptionPane.showMessageDialog(null, "El código del producto debe ser mayor a 0", "Advertencia", JOptionPane.WARNING_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Debe ingresar un dato numérico", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Se ha presentado un Error", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
