package Modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ProductDAO {


    public boolean registrarProducto(ProductVO product) {
        boolean registrado = false;
        Conexion conex = null;
        PreparedStatement consulta = null;

        try {
            conex = new Conexion();
            String query = "INSERT INTO Products (ProductName, SupplierID, CategoryID, QuantityPerUnit, UnitPrice, UnitsInStock, UnitsOnOrder, ReorderLevel, Discontinued) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

            consulta = conex.getConnection().prepareStatement(query);
            consulta.setString(1, product.getProductName());
            consulta.setInt(2, product.getSupplierID());
            consulta.setInt(3, product.getCategoryID());
            consulta.setString(4, product.getQuantityPerUnit());
            consulta.setDouble(5, product.getUnitPrice());
            consulta.setInt(6, product.getUnitsInStock());
            consulta.setInt(7, product.getUnitsOnOrder());
            consulta.setInt(8, product.getReorderLevel());
            consulta.setBoolean(9, product.isDiscontinued());

            int rowsAffected = consulta.executeUpdate();
            if (rowsAffected > 0) {
                registrado = true;
            }

        } catch (SQLException e) {
            System.err.println("Error al registrar el producto: " + e.getMessage());
        } finally {
            try {
                if (consulta != null) {
                    consulta.close();
                }
                if (conex != null) {
                    conex.desconectar();
                }
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }

        return registrado;
    }

    public ProductVO buscarProducto(int productId) {
        ProductVO product = null;

        String query = "SELECT * FROM Products WHERE ProductID = ?";

        Conexion con = null;
        try {
            con = new Conexion();
            Connection conex = con.getConnection();
            PreparedStatement consulta = conex.prepareStatement(query);

            consulta.setInt(1, productId);
            ResultSet res = consulta.executeQuery();
            if (res.next()) {
                product = new ProductVO();
                // product.setProductId(res.getInt("ProductID"));
                product.setProductName(res.getString("ProductName"));
                //product.setSupplierId(res.getInt("SupplierID"));
                //product.setCategoryId(res.getInt("CategoryID"));
                product.setQuantityPerUnit(res.getString("QuantityPerUnit"));
                product.setUnitPrice(res.getDouble("UnitPrice"));
                product.setUnitsInStock(res.getInt("UnitsInStock"));
                product.setUnitsOnOrder(res.getInt("UnitsOnOrder"));
                product.setReorderLevel(res.getInt("ReorderLevel"));
                product.setDiscontinued(res.getBoolean("Discontinued"));
            }
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        } finally {
            if (con != null) {
                con.desconectar();
            }
        }

            return product;
        }


    public boolean actualizarProducto(ProductVO product) {
        boolean actualizado = false;
        Conexion conex = null;
        PreparedStatement consulta = null;

        try {
            conex = new Conexion();
            String query = "UPDATE Products SET ProductName = ?, SupplierID = ?, CategoryID = ?, QuantityPerUnit = ?, UnitPrice = ?, UnitsInStock = ?, UnitsOnOrder = ?, ReorderLevel = ?, Discontinued = ? WHERE ProductID = ?";

            consulta = conex.getConnection().prepareStatement(query);
            consulta.setString(1, product.getProductName());
            consulta.setInt(2, product.getSupplierID());
            consulta.setInt(3, product.getCategoryID());
            consulta.setString(4, product.getQuantityPerUnit());
            consulta.setDouble(5, product.getUnitPrice());
            consulta.setInt(6, product.getUnitsInStock());
            consulta.setInt(7, product.getUnitsOnOrder());
            consulta.setInt(8, product.getReorderLevel());
            consulta.setBoolean(9, product.isDiscontinued());
            consulta.setInt(10, product.getProductID());

            int rowsAffected = consulta.executeUpdate();
            if (rowsAffected > 0) {
                actualizado = true;
            }

        } catch (SQLException e) {
            System.err.println("Error al actualizar el producto: " + e.getMessage());
        } finally {
            try {
                if (consulta != null) {
                    consulta.close();
                }
                if (conex != null) {
                    conex.desconectar();
                }
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }

        return actualizado;
    }

    public boolean borrarProducto(int productId) {
        boolean borrado = false;
        String query = "DELETE FROM Products WHERE ProductID = ?";
        PreparedStatement consulta=null;
        Conexion conex=null;
        try{
            conex = new Conexion();
            Connection conn=conex.getConnection();
            consulta=conn.prepareStatement(query);
            consulta.setInt(1, productId);
            consulta.executeUpdate();
            borrado=true;
        }catch(SQLException e){
            System.err.println("Error al borrar el producto: " + e.getMessage());
        }finally {
            try {
                if (consulta != null) {
                    consulta.close();
                }
                if (conex != null) {
                    conex.desconectar();
                }
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }

    }

}
