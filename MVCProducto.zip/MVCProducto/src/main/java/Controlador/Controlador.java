package Controlador;

import Modelo.Logica;
import Vista.VentanaPrincipal;

public class Controlador {
    VentanaPrincipal ventanaPrincipal;
    public Logica miLogica;

    public void setVentanaPrincipal(VentanaPrincipal ventanaPrincipal) {
        this.ventanaPrincipal = ventanaPrincipal;
    }
}
