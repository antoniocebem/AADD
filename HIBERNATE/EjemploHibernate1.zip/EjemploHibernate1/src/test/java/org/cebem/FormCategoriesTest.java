package org.cebem;

import junit.framework.TestCase;

public class FormCategoriesTest extends TestCase {

}