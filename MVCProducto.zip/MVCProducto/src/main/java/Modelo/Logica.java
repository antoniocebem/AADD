package Modelo;

public class Logica {
}
