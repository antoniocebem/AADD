package Controlador;

import Modelo.Conexion;
import Modelo.Logica;
import Vista.VentanaPrincipal;

public class Principal {

        Logica miLogica;
        Controlador miControlador;
        VentanaPrincipal miVentanaPrincipal;
        //Ventanas

    public static void main(String[] args) {
        Principal principal = new Principal();
        principal.iniciar();
    }

    public void iniciar(){
        miLogica = new Logica();
        Controlador miControlador = new Controlador();
        miVentanaPrincipal = new VentanaPrincipal();

        miVentanaPrincipal.setControlador(miControlador);
        miControlador.setVentanaPrincipal(miVentanaPrincipal);

    }
}
