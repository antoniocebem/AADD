package Vista;

import Controlador.Controlador;
import Modelo.ProductVO;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.ArrayList;

public class ListadoProductos extends javax.swing.JFrame {
    private JPanel ListadoProducto;
    private JTable table1;
    private JScrollPane ScrollPane;
    private Controlador controlador;
    private ArrayList<ProductVO> listaProductos;


    public ListadoProductos() {
        super("ListadoProductos");
        setContentPane(ListadoProducto);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //table1.setModel(model);
        pack();
    }

    public void setControlador(Controlador controlador) {
        this.controlador = controlador;
    }
    public Controlador getControlador() {
        return controlador;
    }
    public void inciarTabla(){
        listaProductos=controlador.devolverProductos();
        DefaultTableModel model = new DefaultTableModel(new String[]{
                "Product ID", "Product Name", "Quantity Per Unit", "Unit Price", "Units In Stock"
        }, 0);

        model.setRowCount(0);
        for (ProductVO producto : listaProductos) {
            System.out.println(producto);
            // Añadir una nueva fila al modelo con los datos del producto
            model.addRow(new Object[]{
                    producto.getProductID(),          // ID del producto
                    producto.getProductName(),        // Nombre del producto
                    producto.getQuantityPerUnit(),    // Cantidad por unidad
                    producto.getUnitPrice(),          // Precio unitario
                    producto.getUnitsInStock()        // Unidades en stock
            });
        }
        table1.setModel(model);


    }
}
