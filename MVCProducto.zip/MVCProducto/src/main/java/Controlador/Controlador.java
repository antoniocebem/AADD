package Controlador;

import Modelo.Logica;
import Modelo.ProductVO;
import Vista.ListadoProductos;
import Vista.VentanaPrincipal;

import java.util.ArrayList;

public class Controlador {
    VentanaPrincipal ventanaPrincipal;
    ListadoProductos listadoProductos;
    public Logica miLogica;

    public VentanaPrincipal getVentanaPrincipal() {
        return ventanaPrincipal;
    }

    public void setVentanaPrincipal(VentanaPrincipal ventanaPrincipal) {
        this.ventanaPrincipal = ventanaPrincipal;
    }

    public ListadoProductos getListadoProductos() {
        return listadoProductos;
    }

    public void setListadoProductos(ListadoProductos listadoProductos) {
        this.listadoProductos = listadoProductos;
    }

    public Logica getMiLogica() {
        return miLogica;
    }

    public void setMiLogica(Logica miLogica) {
        this.miLogica = miLogica;
    }
//////////////////////////////////////////////////////////

    public void mostrarVentanaListado()
    {

        listadoProductos.setVisible(true);
        listadoProductos.inciarTabla();

    }

    public void mostrarVentanaPrincipal(){
        ventanaPrincipal.setVisible(true);
    }


    //////////////////////////////////////////////////////////

    public ArrayList<ProductVO> devolverProductos(){
        return miLogica.validarListado();
    }
}

